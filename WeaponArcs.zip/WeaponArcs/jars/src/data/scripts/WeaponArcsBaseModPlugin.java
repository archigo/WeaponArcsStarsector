/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;

/**
 *
 * @author Archigo
 */
public class WeaponArcsBaseModPlugin extends BaseModPlugin {

}
